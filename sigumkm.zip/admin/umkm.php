
<div class="row">
	<div class="col-lg-12">

	<?php
	if ($lihat == 'Baddurih' || $lihat == 'Barurambat Timur' || $lihat == 'Buddagan' || $lihat == 'Buddih' || $lihat == 'Bunder' || $lihat == 'Dasok' || $lihat == 'Durbuk' || $lihat == 'Jarin' || $lihat == 'Lawangan Daya' || $lihat == 'Lemper' || $lihat == 'Majungan' || $lihat == 'Murtajih' || $lihat == 'Padelegan' || $lihat == 'Pademawu Barat' || $lihat == 'Pademawu Timur' || $lihat == 'Pagagan' || $lihat == 'Prekbun' || $lihat == 'Sentol' || $lihat == 'Sopaah' || $lihat == 'Sumedangan' || $lihat == 'Tambung' || $lihat == 'Tanjung') {
		echo "<h2 class='page-header'>Total UMKM di Desa ".$lihat." : ".$dataDesa."</h2>";
	}else{
		echo "<h2 class='page-header'>Total UMKM Kecamatan Pademawu  : ". $jmlData."</h2>";
	}
	?>

	</div>
</div> <!-- end row -->

<div class="row">
			<div class="col-xs-12 col-md-6 col-lg-4">
				<div class="panel panel-blue panel-widget ">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<svg class="glyph stroked bag"><use xlink:href="#stroked-app-window-with-content"></use></svg>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large"><?php 
							if ($lihat == 'Baddurih' || $lihat == 'Barurambat Timur' || $lihat == 'Buddagan' || $lihat == 'Buddih' || $lihat == 'Bunder' || $lihat == 'Dasok' || $lihat == 'Durbuk' || $lihat == 'Jarin' || $lihat == 'Lawangan Daya' || $lihat == 'Lemper' || $lihat == 'Majungan' || $lihat == 'Murtajih' || $lihat == 'Padelegan' || $lihat == 'Pademawu Barat' || $lihat == 'Pademawu Timur' || $lihat == 'Pagagan' || $lihat == 'Prekbun' || $lihat == 'Sentol' || $lihat == 'Sopaah' || $lihat == 'Sumedangan' || $lihat == 'Tambung' || $lihat == 'Tanjung'){
								echo $jmlIndustriDesa;;
							}else{
								echo $jmlIndustri;
							}
							?></div>
							<div class="text-muted">Industri</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-md-6 col-lg-4">
				<div class="panel panel-orange panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large"><?php 
								if ($lihat == 'Baddurih' || $lihat == 'Barurambat Timur' || $lihat == 'Buddagan' || $lihat == 'Buddih' || $lihat == 'Bunder' || $lihat == 'Dasok' || $lihat == 'Durbuk' || $lihat == 'Jarin' || $lihat == 'Lawangan Daya' || $lihat == 'Lemper' || $lihat == 'Majungan' || $lihat == 'Murtajih' || $lihat == 'Padelegan' || $lihat == 'Pademawu Barat' || $lihat == 'Pademawu Timur' || $lihat == 'Pagagan' || $lihat == 'Prekbun' || $lihat == 'Sentol' || $lihat == 'Sopaah' || $lihat == 'Sumedangan' || $lihat == 'Tambung' || $lihat == 'Tanjung'){
								echo $jmlJasaDesa;;
							}else{
								echo $jmlJasa;
							}
							?></div>
							<div class="text-muted">Jasa</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-md-6 col-lg-4">
				<div class="panel panel-teal panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<svg class="glyph stroked bag"><use xlink:href="#stroked-bag"></use></svg>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large"><?php 
								if ($lihat == 'Baddurih' || $lihat == 'Barurambat Timur' || $lihat == 'Buddagan' || $lihat == 'Buddih' || $lihat == 'Bunder' || $lihat == 'Dasok' || $lihat == 'Durbuk' || $lihat == 'Jarin' || $lihat == 'Lawangan Daya' || $lihat == 'Lemper' || $lihat == 'Majungan' || $lihat == 'Murtajih' || $lihat == 'Padelegan' || $lihat == 'Pademawu Barat' || $lihat == 'Pademawu Timur' || $lihat == 'Pagagan' || $lihat == 'Prekbun' || $lihat == 'Sentol' || $lihat == 'Sopaah' || $lihat == 'Sumedangan' || $lihat == 'Tambung' || $lihat == 'Tanjung'){
								echo $jmlDagangDesa;;
							}else{
								echo $jmlDagang;
							}
							?></div>
							<div class="text-muted">Dagang</div>
						</div>
					</div>
				</div>
			</div>
</div><!--/.row-->

<div class="row">
			<div class="col-xs-12 col-md-6 col-lg-4">
				<div class="panel panel-blue panel-widget ">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<svg class="glyph stroked line-graph"><use xlink:href="#stroked-line-graph"></use></svg>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large"><?php 
								if ($lihat == 'Baddurih' || $lihat == 'Barurambat Timur' || $lihat == 'Buddagan' || $lihat == 'Buddih' || $lihat == 'Bunder' || $lihat == 'Dasok' || $lihat == 'Durbuk' || $lihat == 'Jarin' || $lihat == 'Lawangan Daya' || $lihat == 'Lemper' || $lihat == 'Majungan' || $lihat == 'Murtajih' || $lihat == 'Padelegan' || $lihat == 'Pademawu Barat' || $lihat == 'Pademawu Timur' || $lihat == 'Pagagan' || $lihat == 'Prekbun' || $lihat == 'Sentol' || $lihat == 'Sopaah' || $lihat == 'Sumedangan' || $lihat == 'Tambung' || $lihat == 'Tanjung'){
								echo $jmlMikroDesa;;
							}else{
								echo $jmlMikro;
							}
							?></div>
							<div class="text-muted">Mikro</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-md-6 col-lg-4">
				<div class="panel panel-orange panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<svg class="glyph stroked line-graph"><use xlink:href="#stroked-line-graph"></use></svg>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large"><?php 
							if ($lihat == 'Baddurih' || $lihat == 'Barurambat Timur' || $lihat == 'Buddagan' || $lihat == 'Buddih' || $lihat == 'Bunder' || $lihat == 'Dasok' || $lihat == 'Durbuk' || $lihat == 'Jarin' || $lihat == 'Lawangan Daya' || $lihat == 'Lemper' || $lihat == 'Majungan' || $lihat == 'Murtajih' || $lihat == 'Padelegan' || $lihat == 'Pademawu Barat' || $lihat == 'Pademawu Timur' || $lihat == 'Pagagan' || $lihat == 'Prekbun' || $lihat == 'Sentol' || $lihat == 'Sopaah' || $lihat == 'Sumedangan' || $lihat == 'Tambung' || $lihat == 'Tanjung'){
								echo $jmlKecilDesa;;
							}else{
								echo $jmlKecil;
							}?></div>
							<div class="text-muted">Kecil</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-md-6 col-lg-4">
				<div class="panel panel-teal panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<svg class="glyph stroked line-graph"><use xlink:href="#stroked-line-graph"></use></svg>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large"><?php 
							if ($lihat == 'Baddurih' || $lihat == 'Barurambat Timur' || $lihat == 'Buddagan' || $lihat == 'Buddih' || $lihat == 'Bunder' || $lihat == 'Dasok' || $lihat == 'Durbuk' || $lihat == 'Jarin' || $lihat == 'Lawangan Daya' || $lihat == 'Lemper' || $lihat == 'Majungan' || $lihat == 'Murtajih' || $lihat == 'Padelegan' || $lihat == 'Pademawu Barat' || $lihat == 'Pademawu Timur' || $lihat == 'Pagagan' || $lihat == 'Prekbun' || $lihat == 'Sentol' || $lihat == 'Sopaah' || $lihat == 'Sumedangan' || $lihat == 'Tambung' || $lihat == 'Tanjung'){
								echo $jmlMenengahDesa;;
							}else{
								echo $jmlMenengah;
							}?></div>
							<div class="text-muted">Menengah</div>
						</div>
					</div>
				</div>
			</div>
</div><!--/.row-->

<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">
				Data UMKM Keacamata Pademawu
			</div>
			<div style="margin-top:10px; padding: 0 5px;">
			<a href="?tambah"><button class="btn btn-info"> Tambah Data UMKM</button></a>
			<div class="pull-right">
					<form method="GET" action="">
						Tampilkan : 
						<select class="btn btn-info" style="text-align:left;" name="dataUmkm">
							<option value="<?php echo $lihat; ?>"><?php echo $lihat; ?></option>
							<option value="Baddurih">Baddurih</option>
							<option value="Barurambat Timur">Barurambat Timur</option>
							<option value="Buddagan">Buddagan</option>
							<option value="Buddih">Buddih</option>
							<option value="Bunder">Bunder</option>
							<option value="Dasok">Dasok</option>
							<option value="Durbuk">Durbuk</option>
							<option value="Jarin">Jarin</option>
							<option value="Lawangan Daya">Lawangan Daya</option>
							<option value="Lemper">Lemper</option>
							<option value="Majungan">Majungan</option>
							<option value="Murtajih">Murtajih</option>
							<option value="Padelegan">Padelegan</option>
							<option value="Pademawu Barat">Pademawu Barat</option>
							<option value="Pademawu Timur">Pademawu Timur</option>
							<option value="Pagagan">Pagagan</option>
							<option value="Prekbun">Prekbun</option>
							<option value="Sentol">Sentol</option>
							<option value="Sopaah">Sopaah</option>
							<option value="Sumedangan">Sumedangan</option>
							<option value="Tambung">Tambung</option>
							<option value="Tanjung">Tanjung</option>
							<option value="Industri">Industri</option>
							<option value="Jasa">Jasa</option>
							<option value="Dagang">Dagang</option>
							<option value="Mikro">Mikro</option>
							<option value="Kecil">Kecil</option>
							<option value="Menengah">Menengah</option>
							<option value="Semua">Semua</option>
						</select>
						<input class="btn btn-primary" type="submit" name="tampil" value="terapkan">
					</form>
				</div>
				<div> <!-- end style -->
			<div class="panel-body">
				<table class="table table-hover">
					<tr>
						<thead>
							<th>No</th>
							<th>Nama Pemilik</th>
							<th>Nama UMKM</th>
							<th>Desa</th>
							<th>Alamat</th>
							<th>Jenis Usaha</th>
							<th>Kriteria Usaha</th>
							<th>Kontak</th>
							<th></th>
						</thead>
					</tr>
					<?php 
					$no = 1;
					if ($lihat == 'Baddurih' || $lihat == 'Barurambat Timur' || $lihat == 'Buddagan' || $lihat == 'Buddih' || $lihat == 'Bunder' || $lihat == 'Dasok' || $lihat == 'Durbuk' || $lihat == 'Jarin' || $lihat == 'Lawangan Daya' || $lihat == 'Lemper' || $lihat == 'Majungan' || $lihat == 'Murtajih' || $lihat == 'Padelegan' || $lihat == 'Pademawu Barat' || $lihat == 'Pademawu Timur' || $lihat == 'Pagagan' || $lihat == 'Prekbun' || $lihat == 'Sentol' || $lihat == 'Sopaah' || $lihat == 'Sumedangan' || $lihat == 'Tambung' || $lihat == 'Tanjung'){
						if ($dataDesa < 1) {
							echo "<tr>
								<td colspan='10' class='alert-danger'>Tidak ada data UMKM !</td>
								</tr>";
						}else{
							while ($row = mysqli_fetch_array($showDesa)) {
								echo "<tr>
									<td>$no</td>
									<td>".$row['nama_pemilik']."</td>
									<td>".$row['nama_umkm']."</td>
									<td>".$row['desa']."</td>
									<td>".$row['alamat']."</td>
									<td>".$row['usaha']."</td>
									<td>".$row['kriteria']."</td>
									<td>".$row['kontak']."</td>
									<td><a href='?edit=$row[0]'><span class='glyphicon glyphicon-edit' title='Edit'></span></a> | <a href='?hapus=$row[0]'><span class='glyphicon glyphicon-trash' title='Hapus'></span></a></td>
								</tr>";
							$no++;
								}
						}
					}elseif ($lihat == 'Industri' || $lihat == 'Jasa' || $lihat == 'Dagang') {
						if ($jenisLihat < 1) {
							echo "<tr>
								<td colspan='10' class='alert-danger'>Tidak ada data UMKM !</td>
								</tr>";
						}else{
							while ($row = mysqli_fetch_array($lihatJenis)) {
								echo "<tr>
									<td>$no</td>
									<td>".$row['nama_pemilik']."</td>
									<td>".$row['nama_umkm']."</td>
									<td>".$row['desa']."</td>
									<td>".$row['alamat']."</td>
									<td>".$row['usaha']."</td>
									<td>".$row['kriteria']."</td>
									<td>".$row['kontak']."</td>
									<td><a href='?edit=$row[0]'><span class='glyphicon glyphicon-edit'></span></a> | <a href='?hapus=$row[0]'><span class='glyphicon glyphicon-trash'></span></a></td>
								</tr>";
							$no++;
								}
						}
					}elseif ($lihat == 'Mikro' || $lihat == 'Kecil' || $lihat == 'Menengah') {
						if ($kriteriaLihat < 1) {
							echo "<tr>
								<td colspan='10' class='alert-danger'>Tidak ada data UMKM !</td>
								</tr>";
						}else{
							while ($row = mysqli_fetch_array($lihatKriteria)) {
								echo "<tr>
									<td>$no</td>
									<td>".$row['nama_pemilik']."</td>
									<td>".$row['nama_umkm']."</td>
									<td>".$row['desa']."</td>
									<td>".$row['alamat']."</td>
									<td>".$row['usaha']."</td>
									<td>".$row['kriteria']."</td>
									<td>".$row['kontak']."</td>
									<td><a href='?edit=$row[0]'><span class='glyphicon glyphicon-edit' title='Edit'></span></a> | <a href='?hapus=$row[0]'><span class='glyphicon glyphicon-trash' title='Hapus'></span></a></td>
								</tr>";
							$no++;
								}
						}
					}
					else{
						while ($row = mysqli_fetch_array($data)) {
						echo "<tr>
							<td>$no</td>
							<td>".$row['nama_pemilik']."</td>
							<td>".$row['nama_umkm']."</td>
							<td>".$row['desa']."</td>
							<td>".$row['alamat']."</td>
							<td>".$row['usaha']."</td>
							<td>".$row['kriteria']."</td>
							<td>".$row['kontak']."</td>
							<td><a href='?edit=$row[0]'><span class='glyphicon glyphicon-edit' title='Edit'></span></a> | <a href='?hapus=$row[0]'><span class='glyphicon glyphicon-trash' title='Hapus'></span></a></td>
						</tr>";
						$no++;
					}
				}
					?>
				</table>
			</div>
		</div>
	</div>
</div>