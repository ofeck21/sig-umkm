<?php 
	require_once 'admin/config.php';
 ?>

<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">
				<?php echo $profil['judul']; ?>
			</div>
			<div class="panel-body" align="justify">
				<?php echo $profil['artikel']; ?>
			</div>
		</div>
	</div>
</div> <!-- end row -->