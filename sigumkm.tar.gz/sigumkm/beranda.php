<div class="rows">
	<div class="col-md-8">
		<marquee class="page-header"> Selamat datang di <strong>Sistem Informasi Geografis UMKM Kecamatan Pademawu</strong> !</marquee>
		<div class="maps">
			<div class="maps-desa">
				<a href="?peta=Baddurih"><img src="img/baddurih.png" class="baddurih" title="Baddurih"></a>
				<a href="?peta=Barurambat Timur"><img src="img/barurambat-timur.png" width="50" class="barurambat-timur" title="Barurambat Timur"></a>
				<a href="?peta=Buddagan"><img src="img/buddagan.png" class="buddagan" title="Buddagan"></a>
				<a href="?peta=Buddih"><img src="img/buddih.png" class="buddih" title="Buddih"></a>
				<a href="?peta=Bunder"><img src="img/bunder.png" class="bunder" title="Bunder"></a>
				<a href="?peta=Dasok"><img src="img/dasok.png" class="dasok" title="Dasok"></a>
				<a href="?peta=Durbuk"><img src="img/durbuk.png" class="durbuk" title="Durbuk"></a>
				<a href="?peta=Jarin"><img src="img/jarin.png" class="jarin" title="Jarin"></a>
				<a href="?peta=Lawangan Daya"><img src="img/lawangan-daya.png" class="lawangan-daya" title="Lawangan Daya"></a>
				<a href="?peta=Lemper"><img src="img/lemper.png" class="lemper" title="Lemper"></a>
				<a href="?peta=Majungan"><img src="img/majungan.png" class="majungan" title="Majungan"></a>
				<a href="?peta=Murtajih"><img src="img/murtajih.png" class="murtajih" title="Murtajih"></a>
				<a href="?peta=Pademawu Barat"><img src="img/pademawu-barat.png" class="pademawu-barat" title="Pademawu Barat"></a>
				<a href="?peta=Pademawu Timur"><img src="img/pademawu-timur.png" class="pademawu-timur" title="Pademawu Timur"></a>
				<a href="?peta=Padelegan"><img src="img/padelegan.png" class="padelegan" title="Padelegan"></a>
				<a href="?peta=Prekbun"><img src="img/prekbun.png" class="prekbun" title="Prekbun"></a>
				<a href="?peta=Pagagan"><img src="img/pagagan.png" class="pagagan" title="Pagagan"></a>
				<a href="?peta=Sentol"><img src="img/sentol.png" class="sentol" title="Sentol"></a>
				<a href="?peta=Sumedangan"><img src="img/sumedangan.png" class="sumedangan" title="Sumedangan"></a>
				<a href="?peta=Sopaah"><img src="img/sopaah.png" class="sopaah" title="Sopaah"></a>
				<a href="?peta=Tambung"><img src="img/tambung.png" class="tambung" title="Tambung"></a>
				<a href="?peta=Tanjung"><img src="img/tanjung.png" class="tanjung" title="Tanjung"></a>
			</div>
			<div class="keterangan ket-kiri panel panel-default">
				<div class="panel-heading">Keterangan </div>
				<div class="panel-body">
					<div class="item bg-violet">Des. Baddurih</div>
					<div class="item bg-blue-dr">Kel. Barurambat Timur</div>
					<div class="item bg-yellow">Des. Buddagan</div>
					<div class="item bg-red-br">Des. Buddih</div>
					<div class="item bg-blue-dark">Des. Bunder</div>
					<div class="item bg-green-dr">Des. Dasok</div>
					<div class="item bg-purple">Des. Durbuk</div>
					<div class="item bg-yellow-flat">Des. Jarin</div>
					<div class="item bg-gr-dark">Kel. Lawangan Daya</div>
					<div class="item bg-orange">Des. Lemper</div>
					<div class="item bg-orange-flat">Des. Majungan</div>
				</div>
			</div>
			<img src="img/pademawu.png" width="330" class="pademawu">
			<div class="keterangan pull-right panel panel-default">
				<div class="panel-heading">Keterangan </div>
				<div class="panel-body">
					<div class="item bg-pink">Des. Murtajih</div>
					<div class="item bg-green-flat">Des. Padelegan</div>
					<div class="item bg-green">Des. Pademawu Barat</div>
					<div class="item bg-pinka">Des. Pademawu Timur</div>
					<div class="item bg-purple-flat">Des. Pagagan</div>
					<div class="item bg-cyan-flat">Des. Prekbun</div>
					<div class="item bg-brow">Des. Sentol</div>
					<div class="item bg-blue-flat">Des. Sopaah</div>
					<div class="item bg-cyan">Des. Sumedangan</div>
					<div class="item bg-red">Des. Tambung</div>
					<div class="item bg-blue">Des. Tanjung</div>
				</div>
			</div>
			<div align="center" style="font-size:small; color:#25ad7d;">&copy; Kecamatan Pademawu</div>
		</div>
	</div>
	<div class="col-md-4">
		<div class="thumbnail">
			<img src="img/logo.png">
				<h6>Pemerintah Kabupaten Pamekasan Kecamatan Pademawu</h6>
		</div>
		<div class="panel panel-success panel-margin-top">
			<div class="panel-heading">
				<strong>UMKM Kecamatan Pademawu</strong> <span class="badge pull-right"><?php echo $jmlData; ?></span>
			</div>
			<div class="panel-body">
				<ul class="list-group">
				  <a href="?dataUmkm=Industri"><li class="list-group-item list-group-item-info">Industri <span class="badge"><?php echo $jmlIndustri; ?></span></li></a>
				  <a href="?dataUmkm=Dagang"><li class="list-group-item list-group-item-warning">Dagang <span class="badge"><?php echo $jmlDagang; ?></span></li></a>
				  <a href="?dataUmkm=Jasa"><li class="list-group-item list-group-item-danger">Jasa <span class="badge"><?php echo $jmlJasa; ?></span></li></a>
				</ul>
			</div> <!-- end panel-body --> 
		</div> <!-- end panel -->
	</div>
</div> <!-- end rows -->
